<?php
require_once '../config/database.php';
require_once '../helpers/patient_photo_helper.php';

header('Content-Type: application/json');

function calculateAgeFromDob(?string $dobString): ?int {
    if (empty($dobString)) {
        return null;
    }

    try {
        $dob = new DateTime($dobString);
        $today = new DateTime();
        return $today->diff($dob)->y;
    } catch (Exception $e) {
        return null;
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$email = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');
$aadhaar = $data['aadhaar'] ?? '';
$aadhaar = preg_replace('/\D+/', '', $aadhaar);

$conn = getDBConnection();

if (!empty($email) && !empty($password)) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode([
            'success' => false,
            'message' => 'Please enter a valid email address'
        ]);
        exit;
    }

    $stmt = $conn->prepare(
        "SELECT id, aadhaar_number, name, email, password, date_of_birth, age, gender, address, mobile_number, scheme
        FROM patients
        WHERE email = ?
        LIMIT 1"
    );

    if (!$stmt) {
        echo json_encode([
            'success' => false,
            'message' => 'Query prepare failed: ' . $conn->error
        ]);
        exit;
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $patient = $result->fetch_assoc();
        if (!password_verify($password, $patient['password'])) {
            echo json_encode([
                'success' => false,
                'message' => 'Invalid email or password'
            ]);
            exit;
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid email or password'
        ]);
        exit;
    }
} elseif (!empty($aadhaar)) {
    if (strlen($aadhaar) !== 12 || !preg_match('/^\d{12}$/', $aadhaar)) {
        echo json_encode([
            'success' => false,
            'message' => 'Please enter a valid 12-digit Aadhaar number'
        ]);
        exit;
    }

    $stmt = $conn->prepare(
        "SELECT id, aadhaar_number, name, email, date_of_birth, age, gender, address, mobile_number, scheme
        FROM patients
        WHERE aadhaar_number = ?
        LIMIT 1"
    );

    if (!$stmt) {
        echo json_encode([
            'success' => false,
            'message' => 'Query prepare failed: ' . $conn->error
        ]);
        exit;
    }

    $stmt->bind_param("s", $aadhaar);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $patient = $result->fetch_assoc();
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Patient not found'
        ]);
        exit;
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Email/password or Aadhaar is required for login'
    ]);
    exit;
}

$photoPath = null;
if (function_exists('getPatientPhotoPath')) {
    $photoPath = getPatientPhotoPath($patient['aadhaar_number'] ?? '');
}

$patient['photo_path'] = $photoPath;

if (empty($patient['age']) && !empty($patient['date_of_birth'])) {
    $patient['age'] = calculateAgeFromDob($patient['date_of_birth']);
}

unset($patient['password']);

echo json_encode([
    'success' => true,
    'patient' => $patient,
    'message' => 'Patient found successfully'
]);

$stmt->close();
$conn->close();
?>