<?php
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$aadhaar = preg_replace('/\D+/', '', $data['aadhaar'] ?? '');
$name = trim($data['name'] ?? '');
$email = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');
$confirmPassword = trim($data['confirm_password'] ?? '');
$dob = $data['date_of_birth'] ?? '';
$age = intval($data['age'] ?? 0);
$gender = trim($data['gender'] ?? '');
$address = trim($data['address'] ?? '');
$mobile = preg_replace('/\D+/', '', trim($data['mobile'] ?? ''));
$scheme = $data['scheme'] ?? null;
$scheme_discount = floatval($data['scheme_discount'] ?? 0);

// ✅ Validation
if (strlen($aadhaar) !== 12) {
    echo json_encode(['success' => false, 'message' => 'Invalid Aadhaar number']);
    exit;
}

if (!$name || !$email || !$password || !$dob || !$age || !$gender || !$address || !$mobile) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

if (!$confirmPassword) {
    echo json_encode(['success' => false, 'message' => 'Please confirm the password']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Please enter a valid email address']);
    exit;
}

if ($password !== $confirmPassword) {
    echo json_encode(['success' => false, 'message' => 'Passwords do not match']);
    exit;
}

$conn = getDBConnection();

// ✅ Check if Aadhaar or email already exists
$checkStmt = $conn->prepare("SELECT id FROM patients WHERE aadhaar_number = ? OR email = ?");
$checkStmt->bind_param("ss", $aadhaar, $email);
$checkStmt->execute();
$result = $checkStmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Patient with this Aadhaar or email already exists']);
    exit;
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare(" 
    INSERT INTO patients 
    (aadhaar_number, name, email, password, date_of_birth, age, gender, address, mobile_number, scheme, scheme_discount) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) 
");

if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Query prepare failed: ' . $conn->error]);
    exit;
}

$stmt->bind_param(
    "sssssissssd",
    $aadhaar,
    $name,
    $email,
    $hashedPassword,
    $dob,
    $age,
    $gender,
    $address,
    $mobile,
    $scheme,
    $scheme_discount
);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Patient registered successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>