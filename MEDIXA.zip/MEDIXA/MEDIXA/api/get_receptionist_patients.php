<?php
error_reporting(0);
ini_set('display_errors', 0);

session_start();
require_once '../config/database.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Check if receptionist is logged in
        if (!isset($_SESSION['receptionist_id'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            exit;
        }
        
        $receptionist_id = $_SESSION['receptionist_id'];
        
        $conn = getDBConnection();
        
        if (!$conn) {
            echo json_encode(['success' => false, 'message' => 'Database connection failed']);
            exit;
        }
        
        // Get all patients registered by this receptionist
        $stmt = $conn->prepare("
            SELECT 
                p.id,
                p.aadhaar_number,
                p.name,
                p.date_of_birth,
                p.age,
                p.gender,
                p.address,
                p.mobile_number,
                p.scheme,
                p.scheme_discount,
                p.cause,
                p.assigned_doctor_id,
                p.specialization,
                pr.registration_date,
                pr.status,
                d.doctor_name
            FROM patient_registrations pr
            INNER JOIN patients p ON pr.patient_id = p.id
            LEFT JOIN doctors d ON p.assigned_doctor_id = d.id
            WHERE pr.receptionist_id = ?
            ORDER BY pr.registration_date DESC
        ");
        
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param("i", $receptionist_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $patients = [];
        while ($row = $result->fetch_assoc()) {
            $patients[] = [
                'id' => $row['id'],
                'aadhaar_number' => $row['aadhaar_number'],
                'name' => $row['name'],
                'date_of_birth' => $row['date_of_birth'],
                'age' => $row['age'],
                'gender' => $row['gender'],
                'address' => $row['address'],
                'mobile_number' => $row['mobile_number'] ?? '',
                'scheme' => $row['scheme'] ?? '',
                'scheme_discount' => $row['scheme_discount'] ?? 0,
                'cause' => $row['cause'] ?? '',
                'assigned_doctor_id' => $row['assigned_doctor_id'],
                'specialization' => $row['specialization'] ?? '',
                'doctor_name' => $row['doctor_name'] ?? '',
                'registration_date' => $row['registration_date'],
                'status' => $row['status']
            ];
        }
        
        $stmt->close();
        $conn->close();
        
        echo json_encode(['success' => true, 'patients' => $patients, 'count' => count($patients)]);
        
    } catch (Exception $e) {
        if (isset($conn) && $conn) {
            $conn->close();
        }
        echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>

