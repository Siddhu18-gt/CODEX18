<?php
require_once '../config/database.php';

header('Content-Type: application/json');

function sendJson($success, $message) {
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJson(false, 'Invalid request method');
}

$data = json_decode(file_get_contents('php://input'), true);

$aadhaar = preg_replace('/\D+/', '', $data['aadhaar'] ?? '');
$name = trim($data['name'] ?? '');
$email = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');
$confirmPassword = trim($data['confirm_password'] ?? '');
$dob = $data['date_of_birth'] ?? '';
$age = intval($data['age'] ?? 0);
$gender = trim($data['gender'] ?? '');
$address = trim($data['address'] ?? '');
$mobile = preg_replace('/\D+/', '', trim($data['mobile'] ?? ''));
$scheme = $data['scheme'] ?? null;
$scheme_discount = floatval($data['scheme_discount'] ?? 0);

// ✅ Validation
if (strlen($aadhaar) !== 12) {
    sendJson(false, 'Invalid Aadhaar number');
}

if (!$name || !$email || !$password || !$confirmPassword || !$dob || !$age || !$gender || !$address || !$mobile) {
    sendJson(false, 'All fields are required');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    sendJson(false, 'Please enter a valid email');
}

if ($password !== $confirmPassword) {
    sendJson(false, 'Passwords do not match');
}

$conn = getDBConnection();

// ✅ Check existing
$checkStmt = $conn->prepare("SELECT id FROM patients WHERE aadhaar_number = ? OR email = ?");
$checkStmt->bind_param("ss", $aadhaar, $email);
$checkStmt->execute();
$result = $checkStmt->get_result();

if ($result->num_rows > 0) {
    sendJson(false, 'Patient already exists');
}

$checkStmt->close();


// 🔥 NEW PART: AUTO ASSIGN DOCTOR
$assignedDoctorId = null;

$doctorQuery = $conn->query("SELECT id FROM doctors LIMIT 1");

if ($doctorQuery && $doctorQuery->num_rows > 0) {
    $doctor = $doctorQuery->fetch_assoc();
    $assignedDoctorId = $doctor['id'];
}


// ✅ Insert with doctor
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("
    INSERT INTO patients
    (aadhaar_number, name, email, password, date_of_birth, age, gender, address, mobile_number, scheme, scheme_discount, assigned_doctor_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

if (!$stmt) {
    sendJson(false, 'Query error: ' . $conn->error);
}

$stmt->bind_param(
    "sssssissssdi",
    $aadhaar,
    $name,
    $email,
    $hashedPassword,
    $dob,
    $age,
    $gender,
    $address,
    $mobile,
    $scheme,
    $scheme_discount,
    $assignedDoctorId
);

if ($stmt->execute()) {
    sendJson(true, 'Patient registered & assigned to doctor');
} else {
    sendJson(false, 'Database error: ' . $stmt->error);
}

$stmt->close();
$conn->close();
?>